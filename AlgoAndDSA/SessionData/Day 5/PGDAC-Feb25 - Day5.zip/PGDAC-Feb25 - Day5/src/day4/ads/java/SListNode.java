package day4.ads.java;

public class SListNode {
	int data;
	SListNode next;
}
