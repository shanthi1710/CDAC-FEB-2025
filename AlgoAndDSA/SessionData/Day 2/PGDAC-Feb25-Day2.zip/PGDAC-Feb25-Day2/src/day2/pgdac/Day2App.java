package day2.pgdac;

import java.util.Arrays;

public class Day2App {
	public static void reverseArray(int[] arr, Stack stackObj) {
		for (int i = 0; i < arr.length; ++i) {
			stackObj.push(arr[i]);
		}
/*		
		for (int i = 0; i < arr.length; ++i) {
			arr[i] = stackObj.pop();
		}
*/
		int i = 0;
		while (!stackObj.isEmpty()) {
			arr[i] = stackObj.pop();
			++i;
		}
	}

	public static void main(String[] args) {
		int[] arr = {1, 2, 3, 4, 5};
		
		System.out.println("Before reverse: " + Arrays.toString(arr));

		Stack stackObj = new FixedSizeStack(100);
		reverseArray(arr, stackObj);

		System.out.println("After reverse : " + Arrays.toString(arr));
	}
}
