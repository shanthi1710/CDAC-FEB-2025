package day2.pgdac;

public interface Stack {
	void push(int element);
	int pop();
	//int peek();
	boolean isEmpty();
	boolean isFull();
}
