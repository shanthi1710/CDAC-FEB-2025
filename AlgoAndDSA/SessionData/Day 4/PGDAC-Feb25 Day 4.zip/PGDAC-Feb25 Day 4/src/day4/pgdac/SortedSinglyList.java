package day4.pgdac;

public class SortedSinglyList implements SortedList {
	SListNode head;
	
	public SortedSinglyList() {
		head = null;
	}

	@Override
	public void insert(int element) {
		SListNode newNode = new SListNode();
		newNode.data = element;
		newNode.next = null;
		
		if (head == null) {
			head = newNode;
			return;
		}

		SListNode current = head;
		SListNode previous = null;
		while (current != null) {
			if (current.data > newNode.data) {
				break;
			}
			previous = current;
			current = current.next;
		}

		if (previous == null) {
			// Add newNode as first node.
			newNode.next = head;
			head = newNode;
			return;
		}

		// Add newNode between previous and current.
		previous.next = newNode;
		newNode.next = current;
	}

	@Override
	public void print() {
		SListNode current = head;
		
		while (current != null) {
			System.out.print(current.data + " ");
			current = current.next;
		}
		System.out.println("");
	}

}
