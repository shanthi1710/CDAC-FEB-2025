package day4.pgdac;

public interface SortedList {
	void insert(int element);
	void print();
}
