package day4.pgdac;

public class SinglyList implements List {
	private SListNode head;
	private SListNode tail;
	
	public SinglyList() {
		head = null;
		tail = null;
	}

	@Override
	public void addAtFront(int element) {
		SListNode newNode = new SListNode();
		newNode.data = element;
		newNode.next = head;
		head = newNode;
		
		if (tail == null) {
			tail = head;
		}
	}

	@Override
	public void addAtRear(int element) {
		SListNode newNode = new SListNode();
		newNode.data = element;
		newNode.next = null;
		
		if (isEmpty()) {
			head = newNode;
			tail = newNode;
			return;
		}
		
		tail.next = newNode;
		tail = newNode;
	}

	@Override
	public int deleteFirstNode() {
		if (isEmpty()) {
			// TODO: Throw appropriate exception.
			return -1;
		}

		SListNode temp = head;
		head = head.next;
		
		if (isEmpty()) {
			tail = head;
		}

		return temp.data;
	}

	@Override
	public boolean isEmpty() {
		if (head == null) {
			return true;
		}

		return false;
	}

	@Override
	public void print() {
		SListNode current = head;
		
		while (current != null) {
			System.out.print(current.data + " ");
			current = current.next;
		}
		System.out.println("");
	}

}
