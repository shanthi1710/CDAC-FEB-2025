package day4.pgdac;

import day2.pgdac.Stack;

public class StackUsingList extends SinglyList implements Stack {

	@Override
	public void push(int element) {
		addAtFront(element);
	}

	@Override
	public int pop() {
		return deleteFirstNode();
	}

	@Override
	public boolean isEmpty() {
		return super.isEmpty();
	}

	@Override
	public boolean isFull() {
		return false;
	}

}
