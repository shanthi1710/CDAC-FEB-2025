package day4.pgdac;

public interface List {
	void addAtFront(int element);
	void addAtRear(int element);
	int deleteFirstNode();
	boolean isEmpty();
	void print();
}
