package day4.pgdac;

public class SListNode {
	int data;
	SListNode next;
}
