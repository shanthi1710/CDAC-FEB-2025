package day10.ads.java;

public class SortingAlgorithms {
	public static int loopCount;

	public static void bubbleSort(int[] arr) {
		loopCount = 0;
		
		int elementsToSort = arr.length;
		while (elementsToSort > 1) {
			int left = 0;
			while (left < (elementsToSort - 1)) {
				++loopCount;
				if (arr[left + 1] < arr[left]) {
					int temp = arr[left];
					arr[left] = arr[left + 1];
					arr[left + 1] = temp;
				}
				++left;
			}
			--elementsToSort;
		}
	}

	public static void bubbleSortOptimised(int[] arr) {
		loopCount = 0;
		
		int elementsToSort = arr.length;
		while (elementsToSort > 1) {
			int left = 0;
			int swapCount = 0;
			while (left < (elementsToSort - 1)) {
				++loopCount;
				if (arr[left + 1] < arr[left]) {
					++swapCount;
					int temp = arr[left];
					arr[left] = arr[left + 1];
					arr[left + 1] = temp;
				}
				++left;
			}
			if (swapCount == 0) {
				break;
			}
			--elementsToSort;
		}
	}
	
	public static void selectionSort(int[] arr) {
		loopCount = 0;
		
		int elementPos = 0;
		while (elementPos < (arr.length - 1)) {
			int smallestElementPos = elementPos;
			int i = elementPos + 1;
			while (i < (arr.length)) {
				++loopCount;
				if (arr[i] < arr[smallestElementPos]) {
					smallestElementPos = i;
				}
				++i;
			}
			if (elementPos != smallestElementPos) {
				int temp = arr[elementPos];
				arr[elementPos] = arr[smallestElementPos];
				arr[smallestElementPos] = temp;
			}
			++elementPos;
		}
	}

	public static void insertionSort(int[] arr) {
		loopCount = 0;
		
		int sortedSize = 1;
		while (sortedSize < arr.length) {
			int elementToInsert = arr[sortedSize];
			int i = sortedSize - 1;
			
			while (i >= 0) {
				++loopCount;
				
				if (elementToInsert < arr[i]) {
					arr[i + 1] = arr[i];
				} else {
					break;
				}
				
				--i;
			}
			
			arr[i + 1] = elementToInsert;
			++sortedSize;
		}
	}
}
