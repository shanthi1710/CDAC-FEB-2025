package day10.ads.java;

import java.util.Arrays;

public class Day10App {

	public static void main(String[] args) {
		int[] sortedNums = {1, 2, 3, 4, 5, 6, 7, 9};

		int[] bubbleSortNums = {4, 1, 9, 7, 5, 2, 6, 3};
		System.out.println("*** Bubble Sort ***");
		System.out.println("Before sorting " + Arrays.toString(bubbleSortNums));
		SortingAlgorithms.bubbleSort(bubbleSortNums);
		System.out.println("After sorting " + Arrays.toString(bubbleSortNums));
		System.out.println("Loop count = " + SortingAlgorithms.loopCount);
		SortingAlgorithms.bubbleSort(sortedNums);
		System.out.println("Best case " + Arrays.toString(sortedNums));
		System.out.println("Loop count = " + SortingAlgorithms.loopCount);

		int[] bubbleSortOptimisedNums = {4, 1, 9, 7, 5, 2, 6, 3};
		System.out.println("\n*** Bubble Sort Optimised ***");
		System.out.println("Before sorting " + Arrays.toString(bubbleSortOptimisedNums));
		SortingAlgorithms.bubbleSortOptimised(bubbleSortOptimisedNums);
		System.out.println("After sorting " + Arrays.toString(bubbleSortOptimisedNums));
		System.out.println("Loop count = " + SortingAlgorithms.loopCount);
		SortingAlgorithms.bubbleSortOptimised(sortedNums);
		System.out.println("Best case " + Arrays.toString(sortedNums));
		System.out.println("Loop count = " + SortingAlgorithms.loopCount);

		int[] selectionSortNums = {4, 1, 9, 7, 5, 2, 6, 3};
		System.out.println("\n*** Selection Sort ***");
		System.out.println("Before sorting " + Arrays.toString(selectionSortNums));
		SortingAlgorithms.selectionSort(selectionSortNums);
		System.out.println("After sorting " + Arrays.toString(selectionSortNums));
		System.out.println("Loop count = " + SortingAlgorithms.loopCount);
		SortingAlgorithms.selectionSort(sortedNums);
		System.out.println("Best case " + Arrays.toString(sortedNums));
		System.out.println("Loop count = " + SortingAlgorithms.loopCount);

		int[] insertionSortNums = {4, 1, 9, 7, 5, 2, 6, 3};
		System.out.println("\n*** Insertion Sort ***");
		System.out.println("Before sorting " + Arrays.toString(insertionSortNums));
		SortingAlgorithms.insertionSort(insertionSortNums);
		System.out.println("After sorting " + Arrays.toString(insertionSortNums));
		System.out.println("Loop count = " + SortingAlgorithms.loopCount);
		SortingAlgorithms.insertionSort(sortedNums);
		System.out.println("Best case " + Arrays.toString(sortedNums));
		System.out.println("Loop count = " + SortingAlgorithms.loopCount);
	}

}
