package day13.ads.java;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class AdjacencyMatrix implements Graph {
	int[][] adjMat;
	int vertexCount;
	boolean isDirected;

	public AdjacencyMatrix(int n, boolean isDirected) {
		this.isDirected = isDirected;

		vertexCount = n;

		adjMat = new int[vertexCount][];
		for (int i = 0; i < vertexCount; ++i) {
			adjMat[i] = new int[vertexCount];

			// Set all cells to 0
			for (int j = 0; j < vertexCount; ++j) {
				adjMat[i][j] = 0;
			}
		}
	}

	@Override
	public void addEdge(int u, int v) {
		addEdge(u, v, 1);
	}

	@Override
	public void addEdge(int u, int v, int w) {
		adjMat[u][v] = w;

		if (!isDirected) {
			adjMat[v][u] = w;
		}
	}

	private void dfsHelper(int startVertex, boolean[] isVisited) {
		if (isVisited[startVertex]) {
			return;
		}

		isVisited[startVertex] = true;
		System.out.print(startVertex + " ");

		for (int vj = 0; vj < vertexCount; ++vj) {
			if ((adjMat[startVertex][vj] != 0) && (!isVisited[vj])) {
				dfsHelper(vj, isVisited);
			}
		}
	}

	@Override
	public void printDFS(int startVertex) {
		boolean[] isVisited = new boolean[vertexCount];
		for (int i = 0; i < vertexCount; ++i) {
			isVisited[i] = false;
		}

		dfsHelper(startVertex, isVisited);
		System.out.println("");
	}

	@Override
	public void printBFS(int startVertex) {
		boolean[] isVisited = new boolean[vertexCount];
		for (int i = 0; i < vertexCount; ++i) {
			isVisited[i] = false;
		}

		Queue<Integer> q = new LinkedList<>();

		q.add(startVertex);
		while(!q.isEmpty()) {
			int vi = q.remove();

			if (isVisited[vi]) {
				continue;
			}

			isVisited[vi] = true;
			System.out.print(vi + " ");

			for (int vj = 0; vj < vertexCount; ++vj) {
				if ((adjMat[vi][vj] != 0) && (!isVisited[vj])) {
					q.add(vj);
				}
			}
		}
		System.out.println("");
	}


	private int getVertexWithSmallestDistance(int[] currentDistance, List<Integer> vertexList) {
		int u = vertexList.get(0);
		for (int i = 1; i < vertexList.size(); ++i) {
			int v = vertexList.get(i);
			
			if (currentDistance[v] < currentDistance[u]) {
				u = v;
			}
		}
		Integer uObj = u;
		vertexList.remove(uObj);
		
		return u;
	}
	@Override
	public void dijkstraShortestPath(int startVertex, int destVertex) {
		int[] currentDistance = new int[vertexCount];
		int[] predecessor = new int [vertexCount];
		List<Integer> vertexList = new ArrayList<>();

		for (int i = 0; i < vertexCount; ++i) {
			currentDistance[i] = Integer.MAX_VALUE;
			predecessor[i] = -1;
			vertexList.add(i);
		}

		currentDistance[startVertex] = 0;

		while (!vertexList.isEmpty()) {
			int u = getVertexWithSmallestDistance(currentDistance, vertexList);
			System.out.println("Got vertex " + u + " with current min distance of " + currentDistance[u]);

			for (int v = 0; v < vertexCount; ++v) {
				if (adjMat[u][v] != 0) {
					int distanceToUviaV = currentDistance[u] + adjMat[u][v];
					if (currentDistance[v] > distanceToUviaV) {
						currentDistance[v] = distanceToUviaV;
						predecessor[v] = u;
					}
				}
			}
		}

		System.out.println("Shortest path between " + startVertex + " and " + destVertex + " is " + currentDistance[destVertex]);
		System.out.print("Shortest path is: ");
		int currentVertex = destVertex;
		System.out.print(destVertex);
		while (currentVertex != startVertex) {
			System.out.print(" <- " + predecessor[currentVertex]);
			currentVertex = predecessor[currentVertex];
		}
		System.out.println("");
	}
}
