package day5.ads.java;

public class DListNode {
	public int data;
	public DListNode next;
	public DListNode previous;
	
	public DListNode() {}

	public DListNode(int data) {
		this.data = data;
		next = null;
		previous = null;
	}
}
