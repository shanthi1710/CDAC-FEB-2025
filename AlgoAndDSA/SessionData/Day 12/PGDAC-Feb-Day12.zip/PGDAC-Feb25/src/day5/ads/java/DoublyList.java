package day5.ads.java;

public class DoublyList implements DList {
	private DListNode head;
	private DListNode tail;
	
	public DoublyList() {
		head = null;
		tail = null;
	}

	@Override
	public void addAtFront(int element) {
		DListNode newNode = new DListNode(element);

		if (isEmpty()) {
			tail = newNode;
		} else {
			head.previous = newNode;
		}
		newNode.next = head;
		head = newNode;
	}

	@Override
	public void addAtRear(int element) {
	}

	@Override
	public int deleteFirstNode() {
		return 0;
	}

	@Override
	public boolean isEmpty() {
		if (head == null) {
			return true;
		}

		return false;
	}

	@Override
	public void print() {
		DListNode current = head;
		
		while (current != null) {
			System.out.print(current.data + " ");
			current = current.next;
		}
		System.out.println("");
	}

	@Override
	public void printBackward() {
		DListNode current = tail;
		
		while (current != null) {
			System.out.print(current.data + " ");
			current = current.previous;
		}
		System.out.println("");
	}

}
