package day5.ads.java;

import day4.ads.java.List;
import day4.ads.java.SortedList;

public class Day5App {

	public static void testDoublyList() {
		List l1 = new DoublyList();
		DList l2 = new DoublyList();
		
		l1.addAtFront(5);
		l2.addAtFront(5);
		
		l1.addAtFront(10);
		l2.addAtFront(10);
		
		l1.print();
		
		l2.print();
		l2.printBackward();
	}

	public static void testSortedDoublyList() {
		SortedList l1 = new SortedDList();
		
		l1.insert(5);
		l1.insert(1);
		l1.insert(10);
		l1.insert(3);
		
		l1.print();
	}

	public static void main(String[] args) {
		testSortedDoublyList();
	}

}
