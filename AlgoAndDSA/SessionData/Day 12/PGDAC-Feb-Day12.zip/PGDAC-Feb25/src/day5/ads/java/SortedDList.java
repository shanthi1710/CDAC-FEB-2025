package day5.ads.java;

import day4.ads.java.SortedList;

public class SortedDList implements SortedList {
	private DListNode head;
	private DListNode tail;

	public SortedDList() {
		head = null;
		tail = null;
	}

	@Override
	public void insert(int element) {
		// 1. Create new node
		DListNode newNode = new DListNode(element);

		// 2. If list is empty?
		if (head == null) {
			head = newNode;
			tail = newNode;
			return;
		}

		// 3. Traverse list to find node - current node.
		DListNode current = head;
		while (current != null) {
			if (current.data > element) {
				break;
			}
			current = current.next;
		}

		// 4. If adding before first node?
		if (current == head) {
			head.previous = newNode;
			newNode.next = head;
			head = newNode;
			return;
		}

		// 5. If adding after the last node?
		if (current == null) {
			tail.next = newNode;
			newNode.previous = tail;
			tail = newNode;
			return;
		}

		// 6. Add a new node between current and current's previous node.
		newNode.next = current;
		newNode.previous = current.previous;
		current.previous.next = newNode;
		current.previous = newNode;
	}

	@Override
	public void print() {
		DListNode current = head;
		
		while (current != null) {
			System.out.print(current.data + " ");
			current = current.next;
		}
		System.out.println("");
	}

}
