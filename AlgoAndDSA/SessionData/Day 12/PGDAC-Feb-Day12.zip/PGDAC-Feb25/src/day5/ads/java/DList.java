package day5.ads.java;

import day4.ads.java.List;

public interface DList extends List {
	void printBackward();
}
