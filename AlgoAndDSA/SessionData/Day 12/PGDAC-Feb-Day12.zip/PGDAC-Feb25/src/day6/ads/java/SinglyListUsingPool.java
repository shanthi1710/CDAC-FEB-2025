package day6.ads.java;

import day4.ads.java.List;
import day4.ads.java.SListNode;

public class SinglyListUsingPool implements List {
	SListNode head;
	SListNode tail;
	NodePoolManager nodePoolMgr;
	
	public SinglyListUsingPool() {
		head = null;
		tail = null;
		nodePoolMgr = new NodePoolManager(100);
	}

	@Override
	public void addAtFront(int element) {
		SListNode newNode = nodePoolMgr.createNode(); //new SListNode();
		newNode.data = element;
		newNode.next = head;
		head = newNode;
		
		if (tail == null) {
			tail = head;
		}
	}

	@Override
	public void addAtRear(int element) {
		// TODO Auto-generated method stub
	}

	@Override
	public int deleteFirstNode() {
		if (isEmpty()) {
			// TODO: Throw appropriate exception.
			return -1;
		}

		SListNode temp = head;
		head = head.next;
		
		if (isEmpty()) {
			tail = head;
		}

		int result = temp.data;
		nodePoolMgr.deleteNode(temp);
		return result;
	}

	@Override
	public boolean isEmpty() {
		if (head == null) {
			return true;
		}

		return false;
	}

	@Override
	public void print() {
		SListNode current = head;
		
		while (current != null) {
			System.out.print(current.data + " ");
			current = current.next;
		}
		System.out.println("");
	}

}
