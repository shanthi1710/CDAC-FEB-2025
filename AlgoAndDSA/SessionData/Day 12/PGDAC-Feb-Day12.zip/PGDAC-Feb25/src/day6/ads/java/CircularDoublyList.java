package day6.ads.java;

import day4.ads.java.SortedList;
import day5.ads.java.DListNode;

public class CircularDoublyList implements SortedList {
	private DListNode head;
	
	public CircularDoublyList() {
		head = new DListNode();
		head.next = head;
		head.previous = head;
	}

	@Override
	public void insert(int element) {
		// 1. Create new node
		DListNode newNode = new DListNode(element);

		// 3. Traverse list to find node - current node.
		DListNode current = head.next;
		while (current != head) {
			if (current.data > element) {
				break;
			}
			current = current.next;
		}

		// 6. Add a new node between current and current's previous node.
		newNode.next = current;
		newNode.previous = current.previous;
		current.previous.next = newNode;
		current.previous = newNode;
	}

	@Override
	public void print() {
		DListNode current = head.next;
		
		while (current != head) {
			System.out.print(current.data + " ");
			current = current.next;
		}
		System.out.println("");
	}

	public void printBackward() {
		DListNode current = head.previous;
		
		while (current != head) {
			System.out.print(current.data + " ");
			current = current.previous;
		}
		System.out.println("");
	}
}
