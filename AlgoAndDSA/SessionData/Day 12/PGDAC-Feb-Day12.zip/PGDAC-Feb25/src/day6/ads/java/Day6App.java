package day6.ads.java;

public class Day6App {

	public static void testCircularDoublyList() {
		CircularDoublyList l1 = new CircularDoublyList();
		
		l1.insert(5);
		l1.insert(10);
		l1.insert(1);
		l1.insert(3);
		
		l1.print();
		l1.printBackward();
	}

	public static void main(String[] args) {
		testCircularDoublyList();
	}

}
