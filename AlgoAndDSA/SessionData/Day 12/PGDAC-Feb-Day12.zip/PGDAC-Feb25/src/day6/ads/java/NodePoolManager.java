package day6.ads.java;

import day4.ads.java.SListNode;

public class NodePoolManager {
	SListNode[] nodes;
	boolean[] isFree;
	
	public NodePoolManager(int poolSize) {
		isFree = new boolean[poolSize];
		nodes = new SListNode[poolSize];

		for (int i = 0; i < poolSize; ++i) {
			nodes[i] = new SListNode();
			isFree[i] = true;
		}
	}
	
	public SListNode createNode() {
		for (int i = 0; i < isFree.length; ++i) {
			if (isFree[i]) {
				isFree[i] = false;
				System.out.println("Allocated " + i + "th node.");
				return nodes[i];
			}
		}
		return null; // TODO: Throw appropriate exception.
	}
	
	public void deleteNode(SListNode node) {
		for (int i = 0; i < nodes.length; ++i) {
			if (nodes[i] == node) {
				isFree[i] = true;
				System.out.println("Free " + i + "th node.");
			}
		}
	}
}
