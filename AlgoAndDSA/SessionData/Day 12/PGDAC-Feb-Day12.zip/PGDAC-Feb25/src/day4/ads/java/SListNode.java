package day4.ads.java;

public class SListNode {
	public int data;
	public SListNode next;
}
