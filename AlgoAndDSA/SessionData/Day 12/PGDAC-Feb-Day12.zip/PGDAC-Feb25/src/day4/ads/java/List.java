package day4.ads.java;

public interface List {
	void addAtFront(int element);
	void addAtRear(int element);
	int deleteFirstNode();
	boolean isEmpty();
	void print();
}
