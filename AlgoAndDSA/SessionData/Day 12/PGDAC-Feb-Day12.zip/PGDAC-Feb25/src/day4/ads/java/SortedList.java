package day4.ads.java;

public interface SortedList {
	void insert(int element);
	void print();
}
