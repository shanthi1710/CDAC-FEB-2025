package day4.ads.java;

public class Day4App {
	public static void testSList() {
		List l1 = new SinglyList();
		
		l1.addAtFront(5);
		l1.addAtFront(10);
		l1.addAtFront(15);
		l1.addAtRear(20);
		l1.print();
		
		l1.deleteFirstNode();
		l1.print();
	}

	public static void testSortedList() {
		SortedList l1 = new SortedSinglyList();
		
		l1.insert(5);
		l1.insert(1);
		l1.insert(10);
		l1.insert(7);
		
		l1.print();
	}

	public static void main(String[] args) {
		testSortedList();
	}

}
