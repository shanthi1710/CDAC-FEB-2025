package day4.ads.java;

import day2.ads.java.Stack;
import day6.ads.java.SinglyListUsingPool;

public class StackUsingList extends /*SinglyList*/ SinglyListUsingPool implements Stack {

	@Override
	public void push(int element) {
		addAtFront(element);
	}

	@Override
	public int pop() {
		return deleteFirstNode();
	}

	@Override
	public boolean isEmpty() {
		return super.isEmpty();
	}

	@Override
	public boolean isFull() {
		return false;
	}

}
