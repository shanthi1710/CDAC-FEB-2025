package day12.ads.java;

public interface HashTable {
	void insert(int key);
	boolean search(int key);
}
